"""Add hb column to SensorData

Revision ID: ac0c479127ad
Revises: 
Create Date: 2024-09-30 14:19:21.185717

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ac0c479127ad'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.add_column('sensor_data', sa.Column('hb', sa.Float(), nullable=True))  # Make it nullable first

def downgrade():
    op.drop_column('sensor_data', 'hb')

    # ### end Alembic commands ###
